function setup() { 
  createCanvas(windowWidth, windowHeight);
} 

function draw() { 
  background(220);
  strokeWeight(3);
  stroke('green');
  var x=100;
  while(x<width){
  ellipse(x,50,mouseX,mouseY);
  x= x+100;
  }
}
